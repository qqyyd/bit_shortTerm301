#ifndef READER_H
#define READER_H

#include<QByteArray>
class Reader
{
public:
    Reader();
    static QByteArray recv;
};

#endif // READER_H
