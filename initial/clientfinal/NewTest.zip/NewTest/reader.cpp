#include "reader.h"

QByteArray Reader::recv;
Reader::Reader()
{

}
